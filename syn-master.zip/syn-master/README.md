Syn Package Manager
===================

Syn is a new kind of package manager. It's a package manager that's for
very technical realists. The majority of it's usefulness is only useful
if you put your system into the sort of state where you'd find a problem with
modern package managers.

This package manager was designed, from the bottom up, to deal with flaky
upstreams, cocky developres and problematic code.

Enough talking. Start hacking.
