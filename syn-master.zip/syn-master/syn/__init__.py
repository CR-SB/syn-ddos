# Copyright (c) Syn AUTHORS, 2012, under the terms and conditions of the
# AUTHORS file.

__appname__ = "syn"
__version__ = "0.0~pre1"

__description__ = "Syn Package Manager"
