# Copyright (c) Syn AUTHORS, 2012, under the terms and conditions of the
# AUTHORS file.


class SynException(Exception):
    pass


class NotImplementedException(SynException):
    pass
